from flask import Flask, request, render_template, redirect, url_for, session
import pandas as pd


app = Flask(__name__, template_folder='templates')
app.secret_key = 'asdfghjkjhgfdcvbnmhgfdxcvbmnbvfhhgfcvbn'

class InventoryItem:
    def __init__(self, item_id, name, quantity):
        self.item_id = item_id
        self.name = name
        self.quantity = quantity
        self.sales = {}  # Use dictionary instead of list for faster lookup

    def add_sale(self, employee_id):
        self.sales[employee_id] = self.sales.get(employee_id, 0) + 1

class InventoryManagementSystem:
    def __init__(self):
        self.inventory = {}
        self.sales_by_employee = {}

    def load_inventory_from_excel(self, file_path):
        df = pd.read_excel(file_path)
        for _, row in df.iterrows():
            self.add_item(row['Item ID'], row['Name'], row['Quantity'])

    def add_item(self, item_id, name, quantity):
        self.inventory[item_id] = InventoryItem(item_id, name, quantity)
        self.sales_by_employee[item_id] = {}

    def make_sale(self, item_id, employee_id):
        item = self.inventory.get(item_id)
        if item:
            if item.quantity > 0:
                item.quantity -= 1
                item.add_sale(employee_id)
                self.update_sales_by_employee(item_id, employee_id)
                return f"Sale successful. {item.name} - Quantity: {item.quantity}"
            else:
                return f"Item {item.name} is out of stock."
        return "Item not found in inventory."

    def update_sales_by_employee(self, item_id, employee_id):
        self.sales_by_employee[item_id][employee_id] = self.sales_by_employee[item_id].get(employee_id, 0) + 1

    def get_sales_by_employee(self, item_id):
        return self.sales_by_employee.get(item_id, {})
    
    
    def get_inventory(self):
        inventory_list = []
        for item_id, item in self.inventory.items():
            inventory_list.append({
                'Item ID': item.item_id,
                'Name': item.name,
                'Quantity': item.quantity
            })
        return inventory_list

inventory_system = InventoryManagementSystem()
inventory_system.load_inventory_from_excel(r'inventory.xlsx')

@app.route('/make_sale', methods=['GET', 'POST'])
def make_sale():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    # All logged-in users can access this page.
    if request.method == 'POST':
        item_id = int(request.form['item_id'])
        employee_id = int(request.form['employee_id'])
        message = inventory_system.make_sale(item_id, employee_id)
        return render_template('make_sale.html', message=message)
    return render_template('make_sale.html')

@app.route('/sales_by_employee', methods=['GET'])
def sales_by_employee():
    if not session.get('logged_in') or session.get('user_role') != 'admin':
        return redirect(url_for('home'))
    item_id = request.args.get('item_id')
    item_name = request.args.get('item_name')
    employee_id = request.args.get('employee_id')

    if not item_id and not item_name:
        return render_template('sales_by_employee.html', message="Please provide item ID or item name")

    if item_name:
        item = next((item for item in inventory_system.inventory.values() if item.name == item_name), None)
        if item:
            item_id = item.item_id
        else:
            return render_template('sales_by_employee.html', message="Item not found")

    if employee_id:
        # Assuming inventory_system has a method to get sales by employee ID
        sales_by_employee = inventory_system.get_sales_by_employee_by_id(int(employee_id))
    elif item_id:
        sales_by_employee = inventory_system.get_sales_by_employee(int(item_id))
    else:
        return render_template('sales_by_employee.html', message="Please provide item ID or employee ID")

    return render_template('sales_by_employee.html', sales=sales_by_employee)

@app.route('/get_inventory', methods=['GET'])
def get_inventory():
    if not session.get('logged_in') or session.get('user_role') != 'admin':
        return redirect(url_for('home'))
    inventory_list = inventory_system.get_inventory()
    return render_template('get_inventory.html', inventory=inventory_list)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'admin' and password == 'admin':
            session['logged_in'] = True
            session['user_role'] = 'admin'
            return redirect(url_for('home'))
        elif username == 'sale' and password == 'sale':
            session['logged_in'] = True
            session['user_role'] = 'sale'
            return redirect(url_for('home'))

        else:
            return 'Invalid username or password'
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

@app.route('/', methods=['GET'])
def home():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('home.html')


if __name__ == "__main__":
    app.run(debug=True)
