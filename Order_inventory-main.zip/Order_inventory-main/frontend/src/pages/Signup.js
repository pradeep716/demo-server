// src/pages/Signup.js
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Signup.css"; // Ensure this import is present
import { Link } from "react-router-dom";

const Signup = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    // if (password === confirmPassword) {
    //   // Handle signup logic here
    //   console.log(
    //     "Email:",
    //     email,
    //     "Password:",
    //     password,
    //     "Confirm Password:",
    //     confirmPassword
    //   );
    //   // On successful signup, navigate to login page
    //   navigate("/login");
    // } else {
    //   alert("Passwords do not match");
    // }

    if (password !== confirmPassword) {
      return window.alert("Password doesn't match");
    }

    const res = await fetch("http://localhost:8000/signup", {
      method: "POST",
      headers: {
        "Content-type": "application/json",
      },
      body: JSON.stringify({
        email,
        password,
        confirmPassword,
      }),
    });
    const data = await res.json();
    if (!data) {
      window.alert("Fill the details");
    } else if (res.status === 422) {
      window.alert("User already exist");
    } else {
      window.alert("Registration Successful");
      // console.log("successful");
      navigate("/login");
    }
  };

  return (
    <div className="signup-container">
      <h1>Sign Up</h1>
      <form method="POST">
        <div className="form-group">
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Confirm Password:</label>
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" onClick={handleSubmit}>
          Sign Up
        </button>
      </form>
      <p>
        Already have an account? <Link to="/login">Sign In</Link>
      </p>
    </div>
  );
};

export default Signup;
