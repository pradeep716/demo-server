// import React, { useEffect, useState } from "react";
// import { useInventoryDispatch } from "../Context/InventoryContext";
// import "./RevokeOrder.css";

// const RevokeOrder = () => {
//   const [history, setHistory] = useState([]);
//   const dispatch = useInventoryDispatch();

//   useEffect(() => {
//     const fetchHistory = async () => {
//       try {
//         const res = await fetch("http://localhost:8000/get-history");
//         const data = await res.json();
//         console.log("revoke get history => ", data);
//         setHistory(data);
//       } catch (error) {
//         console.error("Error fetching order history:", error);
//       }
//     };

//     fetchHistory();
//   }, []);

//   const handleRevoke = async (entry) => {
//     try {
//       const res = await fetch("http://localhost:8000/revoke-order", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({ id: entry.id, date: entry.date }),
//       });

//       const data = await res.json();
//       console.log("Revoke response:", data);

//       if (res.status === 200) {
//         dispatch({
//           type: "REVOKE_ORDER",
//           payload: { id: entry.id, date: entry.date },
//         });

//         // Update local state to reflect the revocation
//         setHistory((prevHistory) =>
//           prevHistory.map((order) =>
//             order.id === entry.id && order.date === entry.date
//               ? { ...order, revoked: true }
//               : order
//           )
//         );
//       } else {
//         console.error(`Failed to revoke order: ${data.message}`);
//       }
//     } catch (error) {
//       console.error("Error revoking order:", error);
//     }
//   };

//   return (
//     <div className="revoke-order-container">
//       <h2>Revoke Orders</h2>
//       <table>
//         <thead>
//           <tr>
//             <th>Product ID</th>
//             <th>Product Name</th>
//             <th>Stock Before</th>
//             <th>Stock After</th>
//             <th>Date</th>
//             <th>Action</th>
//           </tr>
//         </thead>
//         <tbody>
//           {history.map((entry, index) => (
//             <tr key={index} className={entry.revoked ? "revoked" : ""}>
//               <td>{entry.id}</td>
//               <td>{entry.productName}</td>
//               <td>{entry.before_stock}</td>
//               <td>{entry.after_stock}</td>
//               <td>{new Date(entry.date).toLocaleString()}</td>
//               <td>
//                 {!entry.revoked && (
//                   <button onClick={() => handleRevoke(entry)}>Revoke</button>
//                 )}
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// export default RevokeOrder;

// corrected code
import React, { useEffect, useState } from "react";
import { useInventoryDispatch } from "../Context/InventoryContext";
import "./RevokeOrder.css";

const RevokeOrder = () => {
  const [history, setHistory] = useState([]);
  const dispatch = useInventoryDispatch();
  const [revokeOrder, setRevokeOrder] = useState("");

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const res = await fetch("http://localhost:8000/get-history");
        const data = await res.json();
        console.log("revoke get history => ", data);
        setHistory(data);
      } catch (error) {
        console.error("Error fetching order history:", error);
      }
    };

    fetchHistory();
  }, []);

  const handleRevoke = async (entry) => {
    try {
      const res = await fetch("http://localhost:8000/revoke-order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          id: entry.id,
          date: entry.date,
          revokeOrder: entry.revokeOrder,
        }),
      });

      const data = await res.json();
      console.log("Revoke response:", data);

      if (res.status === 200) {
        dispatch({
          type: "REVOKE_ORDER",
          payload: {
            id: entry.id,
            date: entry.date,
            revokeOrder: entry.revokeOrder,
          },
        });

        // Update local state to reflect the revocation
        setHistory((prevHistory) =>
          prevHistory.map((order) =>
            order.id === entry.id && order.date === entry.date
              ? { ...order, revoked: true }
              : order
          )
        );
        setRevokeOrder("");
        // setHistory(data);
      } else {
        console.error(`Failed to revoke order: ${data.message}`);
      }
    } catch (error) {
      console.error("Error revoking order:", error);
    }
  };

  const handleRevokeOrderChange = (e, id) => {
    const { value } = e.target;
    setHistory((prevHistory) =>
      prevHistory.map((order) =>
        order.id === id ? { ...order, revokeOrder: value } : order
      )
    );
  };

  return (
    <div className="revoke-order-container">
      <h2>Revoke Orders</h2>
      <table>
        <thead>
          <tr>
            <th>Product ID</th>
            <th>Product Name</th>
            <th>Stock Before</th>
            <th>Stock After</th>
            <th>Date</th>

            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {history.map((entry, index) => (
            <tr key={index} className={entry.revoked ? "revoked" : ""}>
              <td>{entry.id}</td>
              <td>{entry.productName}</td>
              <td>{entry.before_stock}</td>
              <td>{entry.after_stock}</td>
              <td>{new Date(entry.date).toLocaleString()}</td>
              <td>
                {!entry.revoked && (
                  <button onClick={() => handleRevoke(entry)}>Revoke</button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default RevokeOrder;

// import React, { useEffect, useState } from "react";
// import { useInventoryDispatch } from "../Context/InventoryContext";
// import "./RevokeOrder.css";

// const RevokeOrder = () => {
//   const [history, setHistory] = useState([]);
//   const dispatch = useInventoryDispatch();
//   const [revokeOrder, setRevokeOrder] = useState("");

//   useEffect(() => {
//     const fetchHistory = async () => {
//       try {
//         const res = await fetch("http://localhost:8000/get-history");
//         const data = await res.json();
//         console.log("revoke get history => ", data);
//         setHistory(data);
//       } catch (error) {
//         console.error("Error fetching order history:", error);
//       }
//     };

//     fetchHistory();
//   }, []);

//   const handleRevoke = async (entry) => {
//     try {
//       const res = await fetch("http://localhost:8000/revoke-order", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({
//           id: entry.id,
//           date: entry.date,
//           revokeOrder: entry.revokeOrder,
//         }),
//       });

//       const data = await res.json();
//       console.log("Revoke response:", data);

//       if (res.status === 200) {
//         dispatch({
//           type: "REVOKE_ORDER",
//           payload: {
//             id: entry.id,
//             date: entry.date,
//             revokeOrder: entry.revokeOrder,
//           },
//         });

//         // Update local state to reflect the revocation
//         setHistory((prevHistory) =>
//           prevHistory.map((order) =>
//             order.id === entry.id && order.date === entry.date
//               ? { ...order, revoked: true }
//               : order
//           )
//         );
//         setRevokeOrder("");
//         // setHistory(data);
//       } else {
//         console.error(`Failed to revoke order: ${data.message}`);
//       }
//     } catch (error) {
//       console.error("Error revoking order:", error);
//     }
//   };

//   const handleRevokeOrderChange = (e, id) => {
//     const { value } = e.target;
//     setHistory((prevHistory) =>
//       prevHistory.map((order) =>
//         order.id === id ? { ...order, revokeOrder: value } : order
//       )
//     );
//   };

//   return (
//     <div className="revoke-order-container">
//       <h2>Revoke Orders</h2>
//       <table>
//         <thead>
//           <tr>
//             <th>Product ID</th>
//             <th>Product Name</th>
//             <th>Stock Before</th>
//             <th>Stock After</th>
//             <th>Date</th>
//             <th>Revoke Reason</th>
//             <th>Action</th>
//           </tr>
//         </thead>
//         <tbody>
//           {history.map((entry, index) => (
//             <tr key={index} className={entry.revoked ? "revoked" : ""}>
//               <td>{entry.id}</td>
//               <td>{entry.productName}</td>
//               <td>{entry.before_stock}</td>
//               <td>{entry.after_stock}</td>
//               <td>{new Date(entry.date).toLocaleString()}</td>
//               <td>
//                 <input
//                   type="text"
//                   value={entry.revokeOrder || ""}
//                   onChange={(e) => handleRevokeOrderChange(e, entry.id)}
//                 />
//               </td>
//               <td>
//                 {!entry.revoked && (
//                   <button onClick={() => handleRevoke(entry)}>Revoke</button>
//                 )}
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// export default RevokeOrder;
