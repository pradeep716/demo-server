// // src/pages/DefectiveProducts.js
// import React, { useEffect, useState } from "react";
// import {
//   useInventoryState,
//   useInventoryDispatch,
// } from "../Context/InventoryContext";
// import { useNavigate } from "react-router-dom";
// import "./DefectiveProducts.css";

// const DefectiveProducts = () => {
//   const { products } = useInventoryState();
//   const dispatch = useInventoryDispatch();
//   const [product, setProduct] = useState([]);
//   const [selectedProduct, setSelectedProduct] = useState("");
//   const [defectiveQuantity, setDefectiveQuantity] = useState("");
//   const navigate = useNavigate();

//   useEffect(() => {
//     const fetchProduct = async () => {
//       try {
//         const res = await fetch("http://localhost:8000/get-products");
//         const data = await res.json();
//         setProduct(data);
//         console.log("setProduct", data);
//       } catch (err) {
//         console.log("Error while fetching your feeling", err);
//       }
//     };
//     fetchProduct();
//   }, []);
//   const handleProductChange = (e) => {
//     setSelectedProduct(e.target.value);
//   };

//   const handleQuantityChange = (e) => {
//     setDefectiveQuantity(e.target.value);
//   };

//   const handleSubmit = () => {
//     if (selectedProduct && defectiveQuantity) {
//       dispatch({
//         type: "ADD_DEFECTIVE_PRODUCT",
//         payload: {
//           productName: selectedProduct,
//           quantity: parseInt(defectiveQuantity, 10),
//           employeeId: "currentEmployeeId", // Adjust this based on your actual implementation
//         },
//       });
//       navigate("/sales-analytics"); // Navigate to the sales analytics page or any other page
//     }
//   };

//   return (
//     <div className="defective-products-wrapper">
//       <nav className="navigation">
//         <button onClick={() => navigate("/dashboard")}>Dashboard</button>
//         <button onClick={() => navigate("/view-inventory")}>
//           View Inventory
//         </button>
//         <button onClick={() => navigate("/punch-in-order")}>
//           Punch In Order
//         </button>
//         <button onClick={() => navigate("/revoke-order")}>Revoke Order</button>
//         <button onClick={() => navigate("/defective-products")}>
//           Defective Products
//         </button>
//       </nav>
//       <h2>Defective Products</h2>
//       <div className="form-container">
//         <select
//           value={selectedProduct}
//           onChange={handleProductChange}
//           className="filter-select"
//         >
//           <option value="">Select Product</option>
//           {product.map((product) => (
//             <option key={product.productName} value={product.productName}>
//               {product.productName}
//             </option>
//           ))}
//         </select>
//         <input
//           type="number"
//           placeholder="Defective Quantity"
//           value={defectiveQuantity}
//           onChange={handleQuantityChange}
//           className="filter-input"
//         />
//         <button onClick={handleSubmit} className="submit-button">
//           Submit
//         </button>
//       </div>
//     </div>
//   );
// };

// export default DefectiveProducts;

// src/pages/DefectiveProducts.js
import React, { useEffect, useState } from "react";
import {
  useInventoryState,
  useInventoryDispatch,
} from "../Context/InventoryContext";
import { useNavigate } from "react-router-dom";
import "./DefectiveProducts.css";

const DefectiveProducts = () => {
  const { products } = useInventoryState();
  const dispatch = useInventoryDispatch();
  const [product, setProduct] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState("");
  const [defectiveQuantity, setDefectiveQuantity] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const res = await fetch("http://localhost:8000/get-products");
        const data = await res.json();
        setProduct(data);
        // console.log("setProduct", data);
      } catch (err) {
        console.log("Error while fetching your feeling", err);
      }
    };
    fetchProduct();
  }, []);

  const handleProductChange = (e) => {
    setSelectedProduct(e.target.value);
  };

  const handleQuantityChange = (e) => {
    setDefectiveQuantity(e.target.value);
  };

  const handleSubmit = async () => {
    const newData = {
      productName: selectedProduct,
      quantity: parseInt(defectiveQuantity, 10),
      // employeeId: "currentEmployeeId",
    };
    try {
      const res = await fetch("http://localhost:8000/defective-product", {
        method: "POST",
        headers: {
          "Content-type": "application/json",
        },
        body: JSON.stringify(newData),
      });

      const data = res.json();
      if (res.ok && !data.err) {
        if (selectedProduct && defectiveQuantity) {
          dispatch({
            type: "ADD_DEFECTIVE_PRODUCT",
            payload: {
              productName: selectedProduct,
              quantity: parseInt(defectiveQuantity, 10),
              employeeId: "currentEmployeeId",
            },
          });
          setSelectedProduct("");
          setDefectiveQuantity("");
          navigate("/view-inventory");
        }
      }
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div className="defective-products-wrapper">
      <nav className="navigation">
        <button onClick={() => navigate("/dashboard")}>Dashboard</button>
        <button onClick={() => navigate("/view-inventory")}>
          View Inventory
        </button>
        <button onClick={() => navigate("/punch-in-order")}>
          Punch In Order
        </button>
        <button onClick={() => navigate("/revoke-order")}>Revoke Order</button>
        <button onClick={() => navigate("/defective-products")}>
          Defective Products
        </button>
      </nav>
      <h2>Defective Products</h2>
      <div className="form-container">
        <select
          value={selectedProduct}
          onChange={handleProductChange}
          className="filter-select"
        >
          <option value="">Select Product</option>
          {product.map((product) => (
            <option key={product.productName} value={product.productName}>
              {product.productName}
            </option>
          ))}
        </select>
        <input
          type="number"
          placeholder="Defective Quantity"
          value={defectiveQuantity}
          onChange={handleQuantityChange}
          className="filter-input"
        />
        <button onClick={handleSubmit} className="submit-button">
          Submit
        </button>
      </div>
    </div>
  );
};

export default DefectiveProducts;
