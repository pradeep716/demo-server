// src/pages/AddProduct.js
import React, { useState, useEffect } from "react";
import { useInventoryDispatch } from "../Context/InventoryContext";
import { useNavigate } from "react-router-dom";
import "./AddProduct.css";

const AddProduct = () => {
  const dispatch = useInventoryDispatch();
  const [productName, setProductName] = useState("");
  const [stock, setStock] = useState("");
  const [price, setPrice] = useState("");
  const [productId, setProductId] = useState("");
  const [productDetails, setProductDetails] = useState(null);
  const [productIds, setProductIds] = useState([]);
  const navigate = useNavigate();
  const [productImage, setProductImage] = useState("");

  useEffect(() => {
    // Fetch product IDs when component mounts
    const fetchProductIds = async () => {
      try {
        const res = await fetch("http://localhost:8000/product-list");
        const data = await res.json();
        if (res.status === 200 && !data.err) {
          setProductIds(data);
        } else {
          console.error("Failed to fetch product IDs");
        }
      } catch (error) {
        console.error("Error fetching product IDs:", error);
      }
    };

    fetchProductIds();
  }, []);

  const handleFetchProductDetails = async (id) => {
    try {
      const res = await fetch(`http://localhost:8000/product-list/${id}`);
      const data = await res.json();
      if (res.status === 200 && !data.err) {
        setProductDetails(data);
        setProductName(data.name);
        setStock(data.stock);
        setPrice(data.price);
        setProductImage(data.image);
      } else {
        setProductDetails(null);
        setProductName("");
        setStock("");
        setPrice("");
        setProductImage("");
        return window.alert("Product id doesn't exist");
      }
    } catch (error) {
      console.error("Error fetching product details:", error);
      setProductDetails(null);
    }
  };

  const handleAddProduct = async (e) => {
    e.preventDefault();
    const newProduct = {
      id: productId,
      productName,
      stock: parseInt(stock, 10),
      price: parseFloat(price),
      before_stocks: 0,
      image: productImage,
    };

    try {
      const res = await fetch("http://localhost:8000/add-products", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newProduct),
      });

      const data = await res.json();
      if (res.status === 200 && !data.err) {
        // If the product was added successfully, update the context and reset the form
        dispatch({
          type: "ADD_PRODUCT",
          payload: newProduct,
        });
        setProductId("");
        setProductName("");
        setStock("");
        setPrice("");
        setProductImage("");
        return window.alert("Product added successfully");
      } else if (res.status === 202) {
        setProductId("");
        setProductName("");
        setStock("");
        setPrice("");
        setProductImage("");
        return window.alert("added more stocks");
      } else if (res.status === 500) {
        return window.alert("Failed to add product");
      }
    } catch (error) {
      console.error("Error adding product:", error);
    }
  };

  const handleProductIdChange = (e) => {
    const id = e.target.value;
    setProductId(id);
    handleFetchProductDetails(id);
  };

  return (
    <div className="add-product-container">
      <h2>Add Product</h2>
      <form onSubmit={handleAddProduct} method="POST">
        <div className="form-group">
          <label>Product ID:</label>
          <input
            type="text"
            list="product-ids"
            value={productId}
            onChange={handleProductIdChange}
            required
          />
          <datalist id="product-ids">
            {productIds.map((id) => (
              <option key={id} value={id} />
            ))}
          </datalist>
        </div>
        <div className="form-group">
          <label>Product Name:</label>
          <input
            type="text"
            value={productName}
            onChange={(e) => setProductName(e.target.value)}
            required
            readOnly
          />
        </div>
        <div className="form-group">
          <label>Stock:</label>
          <input
            type="number"
            value={stock}
            onChange={(e) => setStock(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Price:</label>
          <input
            type="number"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Product Image:</label>
          {productImage && (
            <img
              src={productImage}
              alt={productName}
              style={{ width: "100px", height: "100px" }}
            />
          )}
        </div>
        <button type="submit">Add Product</button>
      </form>
      <div className="navigation-buttons">
        <button onClick={() => navigate("/dashboard")} className="nav-button">
          Dashboard
        </button>
        <button
          onClick={() => navigate("/update-stock")}
          className="nav-button"
        >
          Punch In Order
        </button>
        <button
          onClick={() => navigate("/view-inventory")}
          className="nav-button"
        >
          View Inventory
        </button>
        <button
          onClick={() => navigate("/revoke-order")}
          className="nav-button"
        >
          Revoke Order
        </button>
      </div>
    </div>
  );
};

export default AddProduct;
