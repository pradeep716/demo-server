// src/pages/Dashboard.js
import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Dashboard.css';

const Dashboard = () => {
  const navigate = useNavigate();

  return (
    <div className="dashboard-wrapper">
      <div className="main-content">
        <div className="header">
          <h1>Welcome to Your Dashboard</h1>
          <p>Select an option below to get started.</p>
        </div>
        <div className="cards-container">
          <div className="card" onClick={() => navigate('/add-product')}>
            <h3>Add Product</h3>
            <p>Add new products to the inventory.</p>
          </div>
          <div className="card" onClick={() => navigate('/view-inventory')}>
            <h3>View Inventory</h3>
            <p>View and manage the inventory of products.</p>
          </div>
          <div className="card" onClick={() => navigate('/update-stock')}>
            <h3>Update Stock</h3>
            <p>Update the stock quantity of existing products.</p>
          </div>
          <div className="card" onClick={() => navigate('/revoke-order')}>
            <h3>Revoke Order</h3>
            <p>Revoke an order and adjust stock levels.</p>
          </div>
          <div className="card" onClick={() => navigate('/defective-products')}>
            <h3>Defective Products</h3>
            <p>Report defective products and manage defective items.</p>
          </div>
          <div className="card" onClick={() => navigate('/sales-analytics')}>
            <h3>Sales Analytics</h3>
            <p>View and analyze sales data.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;