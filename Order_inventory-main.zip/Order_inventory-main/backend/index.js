const express = require("express");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
const cors = require("cors");
const fs = require("fs").promises;
const path = require("path");
const products = require("./data/products.json");
const registerDetail = require("./data/register.json");
const product_list = require("./data/products_list.json");

const app = express();
const PORT = 8000;

dotenv.config({ path: "./config.env" });
app.use(cors());
// Middleware to parse JSON bodies
app.use(express.urlencoded({ extended: false }));
app.use(bodyParser.json());

// to connect database
// require("./db/conn");

// to change in the json file
const productsFilePath = path.join(__dirname, "./data/products.json");
const addedProductFilePath = path.join(__dirname, "./data/added-products.json");
const ordersFilePath = path.join(__dirname, "./data/orders.json");

const readJSONFile = async (filePath) => {
  try {
    const data = await fs.readFile(filePath, "utf8");
    return JSON.parse(data);
  } catch (error) {
    throw new Error(`Error reading file from disk: ${error}`);
  }
};

const writeJSONFile = async (filePath, data) => {
  try {
    fs.writeFile(filePath, JSON.stringify(data, null, 2), "utf8");
  } catch (error) {
    throw new Error(`Error writing file to disk: ${error}`);
  }
};

app.post("/signup", async (req, res) => {
  const { email, password, confirmPassword } = req.body;

  if (!email || !password || !confirmPassword) {
    return res.status(422).json({ error: "fill the all fields!" });
  }

  try {
    // to check if user exists
    const userExist = registerDetail.find(
      (register) => register.email === email
    );

    if (userExist) {
      return res.status(422).json({ message: "user already exists!" });
    } else if (password != confirmPassword) {
      return res.status(422).json({ message: "password does not match" });
    } else {
      registerDetail.push({ id: registerDetail.length + 1, ...req.body });
      fs.writeFile(
        "./data/register.json",
        JSON.stringify(registerDetail),
        (err, data) => {
          // return res.json({ status: "sent" });
        }
      );
      // await user.save(); // save user data for registration

      res.status(201).json({ message: "User Registration Successful" });
    }
  } catch (err) {
    console.log(err);
  }
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;
  // console.log("Body", body);
  if (!email || !password) {
    return res.status(400).json({ message: "Fill the details" });
  }

  try {
    const userExist = registerDetail.find(
      (register) => register.email === email
    );

    // console.log("userExist", userExist);
    const passConfirm = registerDetail.find(
      (pass) => pass.password === password
    );
    // console.log("passconfirm", passConfirm);

    if (userExist) {
      if (passConfirm) {
        // loginDetail.push({ id: loginDetail.length + 1, ...req.body });
        // fs.writeFile(
        //   "./data/login.json",
        //   JSON.stringify(loginDetail),
        //   (err, data) => {
        //     return res.status(200).json({ message: "Logged In successfully" });
        //   }
        // );
        return res.status(200).json({ message: "Logged In successfully" });
      } else {
        return res.status(401).json({ message: "Invalid credenttails" });
      }
    } else {
      return res.status(400).json({ message: "No such user exist" });
    }
  } catch (err) {
    console.log(err);
  }
});

// for addProduct.js to get id, name and price automatically from the backend
app.get("/product-list/:id", (req, res) => {
  try {
    const productId = Number(req.params.id);
    const product = product_list.find((p) => p.id === productId);
    if (product) {
      res.status(200).json(product);
    } else {
      res.status(404).json({ message: "Product not found" });
    }
  } catch (error) {
    res.status(500).json({
      message: "Error fetching product details",
      error: error.message,
    });
  }
});

// to add new product in the json file
app.post("/add-products", async (req, res) => {
  const body = req.body;
  const { productName, stock } = req.body;

  const products = await readJSONFile(productsFilePath);

  // console.log("products => add-prodcts", products);

  const prodExist = products.find((p) => p.productName === productName);
  console.log("prodExist", prodExist);

  if (prodExist) {
    // return res.status(422).json({ message: "Product already exists" });
    // my code :
    prodExist.stock += stock;
    await writeJSONFile(productsFilePath, products);
    res.status(202).json({ message: "added more stocks" });
  } else {
    try {
      // const addedProducts = await readJSONFile(addedProductFilePath);

      const newProduct = { id: Number(products.length) + 1, ...body };
      products.push(newProduct);
      // addedProducts.push(newProduct);

      await writeJSONFile(productsFilePath, products);
      // await writeJSONFile(addedProductFilePath, addedProducts);

      res.json({ status: "Product added successfully" });
    } catch (error) {
      res
        .status(500)
        .json({ message: "Failed to add product", error: error.message });
    }
  }
});

// app.get("/added-products", async (req, res) => {
//   try {
//     const viewProducts = await readJSONFile(addedProductFilePath);
//     res.json(viewProducts);
//   } catch (err) {
//     console.log(err);
//   }
// });

// app.post("/orders", async (req, res) => {
//   const { productName, sales } = req.body;

//   try {
//     // Read products and orders from files
//     const existingProducts = await readJSONFile(productsFilePath);
//     const orders = await readJSONFile(ordersFilePath);

//     // Find the product by name
//     const product = existingProducts.find((p) => p.productName === productName);

//     // Check if product exists and there are enough stocks
//     if (!product || sales < 1 || product.stock < sales) {
//       return res
//         .status(400)
//         .json({ message: "Product unavailable or insufficient stock" });
//     }

//     // Deduct the stock
//     product.stock -= sales;

//     // Save the order
//     orders.push({ id: orders.length + 1, productName, sales });

//     // Write the updated products and orders to their respective files
//     await writeJSONFile(productsFilePath, existingProducts);
//     await writeJSONFile(ordersFilePath, orders);

//     res.json({ status: "Order placed successfully" });
//   } catch (error) {
//     console.error(error);
//     res
//       .status(500)
//       .json({ message: "An error occurred", error: error.message });
//   }
// });

app.post("/orders", async (req, res) => {
  const { productName, sales, employee_id } = req.body;

  // Check for missing fields
  if (!productName || !sales || !employee_id) {
    return res.status(400).json({ message: "Missing required fields" });
  }

  try {
    const existingProducts = await readJSONFile(productsFilePath);
    const orders = await readJSONFile(ordersFilePath);

    // Find the product
    const product = existingProducts.find((p) => p.productName === productName);

    // Check if product exists and if there is sufficient stock
    if (!product || sales < 1 || product.stock < sales) {
      return res
        .status(400)
        .json({ message: "Product unavailable or insufficient stock" });
    }

    const beforeStock = product.stock;
    const afterStock = product.stock - sales;

    // Update product stock
    product.stock = afterStock;

    // Add the new order
    orders.push({
      id: orders.length + 1,
      productName,
      before_stock: beforeStock,
      after_stock: afterStock,
      sales,
      date: new Date().toISOString(),
      employee_id,
    });

    // Write updates to files
    await writeJSONFile(productsFilePath, existingProducts);
    await writeJSONFile(ordersFilePath, orders);

    // Send response
    res.json({ status: "Order placed successfully" });
  } catch (error) {
    console.error(error);
    res
      .status(500)
      .json({ message: "An error occurred", error: error.message });
  }
});

// app.post("/revoke-order", async (req, res) => {
//   const { id, date } = req.body;

//   try {
//     // Read orders and products from file
//     const orders = await readJSONFile(ordersFilePath);
//     const products = await readJSONFile(productsFilePath);

//     // Find the order to revoke
//     const orderIndex = orders.findIndex(
//       (order) => order.id === id && order.date === date
//     );

//     if (orderIndex === -1) {
//       return res.status(404).json({ message: "Order not found" });
//     }

//     const order = orders[orderIndex];

//     // Find the corresponding product
//     const productIndex = products.findIndex(
//       (product) => product.productName === order.productName
//     );

//     if (productIndex === -1) {
//       return res.status(404).json({ message: "Product not found" });
//     }

//     // Update the stock
//     products[productIndex].stock += order.sales;

//     // Mark the order as revoked
//     orders[orderIndex].revoked = true;

//     // Write back the updated orders and products to their files
//     await writeJSONFile(ordersFilePath, orders);
//     await writeJSONFile(productsFilePath, products);

//     res.json({ status: "Order revoked successfully" });
//   } catch (error) {
//     console.error(error);
//     res
//       .status(500)
//       .json({ message: "An error occurred", error: error.message });
//   }
// });

app.post("/revoke-order", async (req, res) => {
  const { id, date, revokeOrder } = req.body;

  try {
    // Read orders and products from file
    const orders = await readJSONFile(ordersFilePath);
    const products = await readJSONFile(productsFilePath);

    // Find the order to revoke
    const orderIndex = orders.findIndex(
      (order) => order.id === id && order.date === date
    );

    if (orderIndex === -1) {
      return res.status(404).json({ message: "Order not found" });
    }

    const order = orders[orderIndex];

    // Find the corresponding product
    const productIndex = products.findIndex(
      (product) => product.productName === order.productName
    );

    if (productIndex === -1) {
      return res.status(404).json({ message: "Product not found" });
    }

    // Update the stock in the products file
    const product = products[productIndex];
    product.stock += order.sales;

    // Update the after_stock field in the orders file
    orders[orderIndex].revoked = true;
    orders[orderIndex].revokeOrder = revokeOrder;

    orders[orderIndex].after_stock = product.stock;

    // changes done by me
    orders[orderIndex].sales = 0;

    // orders[orderIndex].sales = sales - revokeOrder;

    // Write back the updated orders and products to their files
    await writeJSONFile(ordersFilePath, orders);
    await writeJSONFile(productsFilePath, products);

    res.json({ status: "Order revoked successfully" });
  } catch (error) {
    console.error(error);
    res
      .status(500)
      .json({ message: "An error occurred", error: error.message });
  }
});

app.get("/get-products", async (req, res) => {
  try {
    const products = await readJSONFile(productsFilePath);
    res.json(products);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error fetching products", error: error.message });
  }
});

app.get("/get-history", async (req, res) => {
  try {
    const history = await readJSONFile(ordersFilePath);
    res.json(history);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error fetching order history", error: error.message });
  }
});

// app.get("/sales-data", async (req, res) => {
//   try {
//     const orders = await readJSONFile(ordersFilePath);
//     const products = await readJSONFile(productsFilePath);
//     const salesData = orders.map((order) => ({
//       productName: order.productName,
//       stockBefore: order.before_stock,
//       stockAfter: order.after_stock,
//       date: order.date,
//       employeeId: order.employee_id,
//       revoked: order.revoked || false,
//     }));
//     res.json(salesData);
//   } catch (error) {
//     res
//       .status(500)
//       .json({ message: "Failed to fetch sales data", error: error.message });
//   }
// });

app.get("/sales-data", async (req, res) => {
  try {
    const orders = await readJSONFile(ordersFilePath);
    res.json(orders);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Failed to fetch sales data", error: error.message });
  }
});

// app.get("/best-employees", async (req, res) => {
//   try {
//     const { limit } = req.query;
//     const orders = await readJSONFile(ordersFilePath);

//     const employeeSales = {};

//     orders.forEach((order) => {
//       if (!employeeSales[order.employeeName]) {
//         employeeSales[order.employeeName] = 0;
//       }
//       employeeSales[order.employeeName] += order.sales;
//     });

//     const bestEmployees = Object.entries(employeeSales)
//       .sort(([, a], [, b]) => b - a)
//       .slice(0, limit)
//       .map(([name, sales]) => ({ name, sales }));

//     res.json(bestEmployees);
//   } catch (error) {
//     res
//       .status(500)
//       .json({ message: "Error fetching best employees", error: error.message });
//   }
// });

// app.get("/best-products", async (req, res) => {
//   try {
//     const { limit } = req.query;
//     const orders = await readJSONFile(ordersFilePath);

//     const productSales = {};

//     orders.forEach((order) => {
//       if (!productSales[order.productName]) {
//         productSales[order.productName] = 0;
//       }
//       productSales[order.productName] += order.sales;
//     });

//     const bestProducts = Object.entries(productSales)
//       .sort(([, a], [, b]) => b - a)
//       .slice(0, limit)
//       .map(([name, sales]) => ({ name, sales }));

//     res.json(bestProducts);
//   } catch (error) {
//     res
//       .status(500)
//       .json({ message: "Error fetching best products", error: error.message });
//   }
// });

app.post("/defective-product", async (req, res) => {
  const { productName, quantity } = req.body;

  try {
    const products = await readJSONFile(productsFilePath);

    if (!Array.isArray(products)) {
      return res.status(500).json({ message: "Products data is not an array" });
    }

    const product = products.find((p) => p.productName === productName);

    if (product) {
      product.stock = Math.max(product.stock - quantity, 0);

      // changing code

      await writeJSONFile(productsFilePath, products);

      return res.status(200).json(product);
    } else {
      return res.status(404).json({ message: "Product not found" });
    }
  } catch (error) {
    return res
      .status(500)
      .json({ message: "An error occurred", error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
